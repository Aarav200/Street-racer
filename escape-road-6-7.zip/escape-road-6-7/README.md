# Escape Road 6-7

A Pen created on CodePen.

Original URL: [https://codepen.io/Aarav-Chawla-the-selector/pen/NPNerGV](https://codepen.io/Aarav-Chawla-the-selector/pen/NPNerGV).

